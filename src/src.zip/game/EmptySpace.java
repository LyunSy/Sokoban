package game;

import javax.swing.*;
import java.awt.*;

public class EmptySpace extends Elements {

    public EmptySpace(int x, int y){
        super(x,y, new ImageIcon("src/images/emptySpace.png"));
    }

}
