package game;

import javax.swing.*;
import java.awt.*;

public class Goal extends Elements{

    public Goal(int x, int y) {
        super(x, y, new ImageIcon("src/images/goal.png"));
    }

}
