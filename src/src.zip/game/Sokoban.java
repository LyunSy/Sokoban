package game;

public class Sokoban {
    public static void main(String[] args) {

        Window window = new Window();
        window.setVisible(true);
    }
}