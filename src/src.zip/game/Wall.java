package game;

import javax.swing.*;
import java.awt.*;

public class Wall extends Elements {


    public Wall(int x, int y) {
        super(x, y, new ImageIcon("src/images/wall.png"));
    }
}
